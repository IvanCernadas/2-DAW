﻿using Microsoft.AspNetCore.Mvc;


namespace CernadasFragueiroIvanTarea3.Models
{
    public class Asignaturas
    {
       public int Id { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
    }
}
